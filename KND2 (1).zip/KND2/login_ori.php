<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="with-decide-width, initial-scale=2.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge"> 
        <title>Login form design</title>
        <title> javascript email and password validation </title>
        <link rel="stylesheet" href="./style.css">
    </head>
    <body>
        <div class="container">
            <form id = "form" action="/" method="get">
               <h1>Login Form</h1>
               <div class="form group">
                    <label for="email">Email</label>
                    <input id="email" name="email" type="text" class="form-control" onblur="email_validation()" required >
                    <div for="email-error"> </div>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input id="password" name="password" type="password" class="form-control" onblur="password_validation()" required >
                    <div for="password-error"> </div>
                </div>
                <button type="button" class="btn" onclick="isValidationPassed()">Submit</button>
            </form>
        </div>
    </body>
    <script src="validation.js"></script>
</html>