<form method="post" style="background-color:LightGrey;">
<head>
<link href="assets/css/style.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
 <!-- ======= Login Us Section ======= -->
 <section id="login" class="about">
 <div class="container" data-aos="fade-up">

         
<h1><b>Multi_Apply App</b></h1>

<div class="section-title">

<div class="container" data-aos="fade-up">
</head>
<body>
<h2><b>LOGIN</b></h2>

  <br>
  <!-- Username -->
  <div class="form-outline mb-1">
    <label class="form-label" for="userEmail">Username:</label>
    <input type="email" id="userEmail" name="userEmail" size="10" align="middle"/><br>
  </div>
    <br>
  <!-- Password -->
  <div class="form-outline mb-1">
    <label class="form-label" for="password">Password:</label>
    <input type="password" id="password" name="password" size="10" align="middle"/><br><br>
  </div>
    <br>
    <div class="col">
      <!-- Simple link -->
      <a href="forgotpassword.php">Forgot password?</a>
    </div>
  </div>
    <br>
  <!-- Submit button -->
  <button type="button" class="btn btn-primary btn-block mb-" style="color:White;"><a href="index1.php">Login</a></button>
    <br>

      
  <!-- Register button -->
  <div class="text-center">
    <p>First time visiting?...if so click <a href="registration.html">Register</a> button to register</p>
  </div>
  </div>
  </form>

</div>
 </section><!-- End Login Section -->
 <script src="assets/js/main.js"></script>
<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

</body>
 </form>

<?php

require_once'connection.php';

$userEmail = $password =" ";

if(isset($_POST['userEmail']))
{
  $userEmail= $_POST['userEmail'];
	$password = $_POST['password'];



}

if(isset($_POST['save']))
{

$query = "INSERT INTO login(userEmail,password)VALUES('$userEmail','$password')";

$result = $con->query($query);

if(!$result)
{die($con->error);
echo"alert('There was an issue uploading your details,please try again or contact your teacher')";
}
else
{

echo"alert('REGISTRATION SUCCESSFULL!')";
}
}
?>