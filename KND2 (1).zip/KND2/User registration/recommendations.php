
  <!-- ======= Recommendations Section ======= -->
<form style="background-image: url('des.jpg')">
    <section id="recommend" class="about">
      <div class="container" data-aos="fade-up">

<h3>Faculties and Sport Recommendations</h3>
<form method="POST">
<table width="450pix">
</tr>
<tr>
<td>
<hr>
<label for="Grade_of_Entry:">Grade of Entry:</label>
</td>
<td>
<input type="text="value=""maxlength="50"size="30" id="grade" name="grade">
</td>
</tr>
<tr>
<td>
<hr>
<label for="Proposed_Date_of_Entry:">Proposed Date of Entry:</label>
</td>
<td>
<input type="text number"="Proposed_Date_of_Entry"maxlength="50" size = "30" id="date" name="date">
</td>
</tr>
</table width="450pix">
<form>
<style>
form {text-align:left}
</style>
		<fieldset>
			<strong><br>
		    </strong>
			<h1></h1><legend style = "color:dodgerblue"><strong>Contact information</strong></legend></h1>
        
          <br>
	      </strong>
		  <div>
		    <strong>
			    <label for="Email">
			      <span>Email Address:</span>
			      <input type="text" id="userEmail" name="userEmail" />
	        </label>
		    <label for="Cellphone"><span>Cell Phone Number:
                <input type="text" id="number" name="number" />
		    </span></label>
		    <label for="Cell Phone Number"><br>
	        </label>
			    
		    <label for="Work Phone Number(if applicable)"><span><br>
	        </span></label>
		    <h1></h1><legend style = "color:dodgerblue">Medical Information
				<legend><br></h1>
	        </legend>
		    </legend>
		    </strong></div>
		  <div>
		    <p><strong>
	        <label for="Allergy">
            <span>Allergies:</span></label>
	        </strong><strong>
            <input type="text" id="allergy" name="allergy"/>
            </strong></p>
		    <p><strong>
	        <label for="sport"><span>Student interested in sport:</span>
                  <br>
	          <label for="yes">
		      <br>
		      <input type="radio" name="sport" id="sport" value="yes">
	        yes</label>
		    <br>
  <input type="radio" id="sport" name="sport" value="no">
  <label for="sport_no">no</label>
            </label>
		    </strong></p>
		  
			<p><strong>Requires further assistance in applications process</strong><strong><span>:</span>
                 <br>
               <label for="yes">
		      <br>
		      <input type="radio" name="assistance" id="assistance" value="yes">
	        yes</label>
		    <br>
  <input type="radio" id="assistance" name="assistance" value="no">
  <label for="app_no">no</label>
			</strong></p>

     <p><strong>
		    GENDER<br>
		    <label for="male">
		      <input type="radio" id="male" name="gender" value="m">
		      Male</label>
        <input type="radio" id="female" name="gender" value="f">
        <label for="female">Female</label>
        <input type="radio" id="other" name="gender" value="o">
        <label for="other">Other</label></p>
		  </div>	
			
		      <tr><td><input type='submit' value='SAVE' name ='save'></td><td><input type='submit' value ='CANCEL'></td></tr>
		      <br>
		      
		      
    </fieldset>		
			
</form>

      </div>
    </section><!-- End Recommendations Section -->

<?php

require_once'connection.php';

$grade = $dateProposed = $userEmail = $cellphone = $allergy = $sport = $accademicAssist =" ";

if(isset($_POST['grade']))
{
  $grade= $_POST['grade'];
	$date = $_POST['date'];
        $email= $_POST['email'];
	$number = $_POST['number'];
	$allergy = $_POST['allergy'];
        $sport = $_POST['sport'];
        $assistance = $_POST['assistance'];
        $gender = $_POST['gender']
}

if(isset($_POST['save']))
{

$query = "INSERT INTO users(grade,date,email,number,allergy,sport,assistance,gender)VALUES('$grade','$date','$email','$number','$allergy','$sport','$assistance','$gender')";

$result = $con->query($query);

if(!$result)
{die($con->error);
echo"alert('There was an issue uploading your details,please try again or contact your teacher')";
}
else
{

echo"alert('Data captured successfully!')";
}
}
?>

