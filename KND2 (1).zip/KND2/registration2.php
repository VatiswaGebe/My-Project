<!DOCTYPE html>
<html lang="en">
<form method='post' class="form" style="background-color:LightGrey;">
<link href="assets/css/style.css" rel="stylesheet">
<div class="container" data-aos="fade-up">


<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration Form</title>
  <link rel="stylesheet" href="CSS/style.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>
  <div class="form-container">
 <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="50">
          <img src="userf.png" class="img-fluid animated" alt="">
 </div>
    <div class="form-container__details">
      <div class="form-container__title"><h2>MULTI_APPLY APPLICATION</h1></div>
      <div class="form-container__title"><h3>REGISTRATION FORM</h2></div>
    </div>
      <form method='POST'>
      <div class="form__field">
        <div class="form__label"><b>First Name</b></div>
         <input type="text" name="firstname" placeholder="FirstName" autofocus="autofocus" id="firstname" required pattern="[A-Za-z]{3-20}" title="Only alphabets allowed">
      </div>
      <div class="form__field">
        <div class="form__label"><b>Last Name</b></div>
         <input type="text" name="lastname" placeholder="LastName" autofocus="autofocus" id="lastname" required pattern="[A-Za-z]{3-20}" title="Only letters Allowed">   
         
      </div>
<div class="form__field">
        <div class="form__label"><b>ID Number</b></div>
        <input class="form__input" id="idNumber" name="idNumber" required pattern="[0-9]{13}" title="ID number should contain numbers with 13 characters"/>
      </div>
     <div class="form__field">
        <div class="form__label"><b>Email Address<b></div>
        <input class="form__input" id="userEmail" name="userEmail" required title="Email Must end with '@gmail.com'"/>
      </div> 
      <div class="form__field">
        <div class="form__label"><b>Physical Address</b></div>
        <input class="form__input" id="physicalAddress" name="physicalAddress" required/>
      </div>
      <p><strong>
		    GENDER<br>
		    <label for="male">
		      <input type="radio" id="male" name="gender" value="m">
		      Male</label>
        <input type="radio" id="female" name="gender" value="f">
        <label for="female">Female</label>
        <input type="radio" id="other" name="gender" value="o">
        <label for="other">Other</label></p>
      <div class="form__field">
        <div class="form__label"><b>Password</b></div>
        <input class="form__input" type="password" id="password" name="password" required/>
      </div>
       
     <div class="form__field">
        <div class="form__label"><b>Confirm Password</b></div>
        <input class="form__input" type="password" id="password" name="retypePassword" required/>
      </div>
      <br>
      <tr><td><input type='submit' value='SAVE' name ='save'></td><td></td></tr>

      <div class="form-container__line-divider"></div>
    <div class="form-container__links">
     
     
    
     
    <div class="form-container__line-divider"></div>
    <div class="form-container__links">
        
      <class="form-container__link">Already have a password?</a>
      <a href="login5.php" class="form-container__link">Login</a>
    </div>
    </div>
  </div>
   
<!-- Optional theme -->
</form>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</body>
</div>

 <script src="assets/js/main.js"></script>
</html>


<?php

require_once'connection.php';

$firstName = $lastName= $idNumber = $userEmail = $physicalAddress = $gender = $password = $retypePassword =" ";

if(isset($_POST['firstName']))
{
  $firstName= $_POST['firstName'];
	$lastName = $_POST['lastName'];
  $idNumber= $_POST['idNumber'];
	$userEmail = $_POST['userEmail'];
	$physicalAddress = $_POST['physicalAddress'];
  $gender = $_POST['gender'];
  $password = $_POST['password'];
  $retypePassword = $_POST['retypePassword'];


}

if(isset($_POST['save']))
{


$query = "INSERT INTO user_information(firstName,lastName,idNumber,userEmail,physicalAddress,gender,password,retypePassword)VALUES('$firstName','$lastName','$idNumber','$userEmail','$physicalAddress','$gender','$password','$retypePassword')";

$result = $con->query($query);

if(!$result)
{die($con->error);
echo"alert('There was an issue uploading your details,please try again or contact an administrator')";
}
else
{

echo"alert('REGISTRATION SUCCESSFULL!')";
}
}