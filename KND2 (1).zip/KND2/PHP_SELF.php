<form>
<div class="form__field">
        <div class="form__label"><b>First Name</b></div>
         <input type="text" name="firstname" placeholder="FirstName" autofocus="autofocus" id="lastname" required "<?php echo $_POST['firstname']; ?>">   
         <?php echo "<p class='note'>".$msg_n."</p>";?>
         <?php echo "<p class='note'>".$msg2_n."</p>";?>
      </div>
      <div class="form__field">
        <div class="form__label"><b>Last Name</b></div>
         <input type="text" name="lastname" placeholder="LastName" autofocus="autofocus" id="lastname" required "<?php echo $_POST['lastname']; ?>">   
         <?php echo "<p class='note'>".$msg_l."</p>";?>
         <?php echo "<p class='note'>".$msg2_l."</p>";?>
      </div>
</form>


if(isset($_POST['save']))
{

if(empty($_POST['firstname'])){
$msg_n = "You must supply your name";
$name_subject = $_POST['firstname'];
$name_pattern = '/^[a-zA-Z ]*$/';
preg_match($name_pattern, $name_subject, $name_matches);
}
if(!$name_matches[0]){
$msg2_n = "Only alphabets and white space allowed";
}

if(empty($_POST['lastname'])){
$msg_l = "You must supply your name";
$name_subject = $_POST['lastname'];
$name_pattern = '/^[a-zA-Z ]*$/';
preg_match($name_pattern, $name_subject, $name_matches);
}
if(!$name_matches[0]){
$msg2_l = "Only alphabets and white space allowed";
}
}