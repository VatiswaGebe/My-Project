<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Multi_Apply App - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  
  <link href="assets/css/style.css" rel="stylesheet">

 
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="index.html">Multi_Apply App</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="LMS_Popup_Mockup2-600x712.jpg" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#staff">Staff</a></li>
          <li><a class="nav-link scrollto" href="#recommend">Recommendations</a></li>
          <li><a class="nav-link scrollto" href="#sports">Sports</a></li>
          <li class="dropdown"><a href="#university"><span>Applications</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#university">University Applications</a></li>
              <li><a href="#bursary">Bursaries/Funding</a></li>
              <li class="dropdown"><a href="#"><span>Faculties</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#law">Law</a></li>
                  <li><a href="#health">Health Science</a></li>
                  <li><a href="#engineering">Engineering and Information Technology</a></li>
                  <li><a href="#education">Education</a></li>
                  <li><a href="#humanities">Humanities</a></li>
                </ul>
              </li>
            </ul>
          </li>
          <li><a class="getstarted scrollto" href="login5.php"><b>Logout</b></a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
          <h1>To a more bright future for the youth</h1>
          <h2>Let us share the most valuable resources to achieve academic success</h2>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <a href="#about" class="btn-get-started scrollto">Here is what we offer</a>
              
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="4b15894679e3ff530901.webp" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

   

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>About Us</h2>
        </div>
         <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="images-4.jpg" class="img-fluid" alt="">
          </div>
        <div class="row content">
          <div class="col-lg-6">
            <p>WE HAVE CREATED A SCHOOL-BASED WEBSITE THAT OFFERS INFORMATION OF SCHOOL RESOURCES, <br>
                  A WEBSITE THAT ASSISTS MAINLY THE GRADE 12 LEARNERS WITHIN THE SCHOOL WHO WISH TO APPLY <br>
                  FOR HIGHER EDUCATION. UNIVERSITIES AVAILABLE IN THIS WEBSITE OFFERS COURSES THAT ARE IN<br>
                  LINE WITH SUBJECTS BEING DONE AT THE SCHOOL.​
                  THIS PARTICULAR WEBSITE IS AIMED AT SOLVING A PROBLEM OF EDUCATED LEARNERS STRUGGLING TO FURTHER THEIR STUDIES. <br>
                  BY DOING SO, THE ACCURATE AND AN ABUNDANCE OF AVAILABLE LINKS FOR APPLICATION WILL BE ACCESSIBLE WITHIN THIS WEBSITE.<br>
                  THE APPLICATION PLATFORMS SOMETIMES IS NOT ACCESSIBLE ONLINE FOR PEOPLE TO ENGAGE THEMSELVES,<br> 
                  HENCE WE DECIDED TO COME UP WITH THIS WEBSITE TO EASE THINGS.​
              </p>
           
          </div>
          <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="R.jpg" class="img-fluid animated" alt="">
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->


    <!-- ======= Staff Section ======= -->
    <section id="staff" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Staff</h2>
        
        <h4><b>Advisor on Law studies and Teacher in the High School</b></h4> 
          <p>Mr K Somagaca<br>
             Contact number: 083 456 7890 </p>

               <h4><b>Advisor in Humanities Faculty</b></h4>
                   <p>Mrs V Gebe<br>
                      Contact number: 082 855 8123
                   </p>
               <h4><b>Advisor in the field of Health Sciences</b></h4>
                   <p>Mrs A Rasmeni<br>
                      Contact number: 072 920 5467
                   </p>
               <h4><b>Advisor focused in Engineering and Information Technology</b></h4>
                   <p>Mr SA Nogemane<br>
                      Contact number: 081 230 4356
                   </p>
               <h4><b>Advisor in Education</b></h4>
                   <p>Mr O Mahlakatha<br>
                   Contact number: 078 420 3812
                    </p>
         
        </div>
      </div>
    </section><!-- End Staff Section -->

  <!-- ======= Recommendations Section ======= -->
    <section id="recommend" class="about">
      <div class="container" data-aos="fade-up">

<h3>Faculties and Sport Recommendations</h3>
<form method = "post">
<table width="450pix">
</tr>
<tr>
<td>
<hr>
<label for="Grade_of_Entry:">Current Grade:</label>
</td>
<td>
<input type="text="value=""maxlength="50"size="30" id = "grade" name = "grade">
</td>
</tr>
<tr>
<td>
<hr>
<label for="Proposed_Date_of_Entry:">Proposed Date of Entry:</label>
</td>
<td>
<input type="text"="Proposed_Date_of_Entry"maxlength="50" size = "30" id = "date" name = "date">
</td>
</tr>
</table width="450pix">
<form>
<style>
form {text-align:left}
</style>
		<fieldset>
			<strong><br>
		    </strong>
			<h1></h1><legend style = "color:dodgerblue"><strong>Contact information</strong></legend></h1>
        
          <br><br>
	      </strong>
		  <div>
		    <strong>
			    <label for="Email">
			      <span>Email Address:</span>
			      <input type="text" id = "email" name = "email"/>
	        </label>
          <br><br>
		    <label for="Number"><span>Cell Phone Number:
            <input type="number" id = "number" name = "number"/>
		    </span></label>
			    
		    <label for="Work Phone Number(if applicable)"><span><br>
	        </span></label>
		    <h1></h1><legend style = "color:dodgerblue">Medical Information
				<legend><br></h1>
	        </legend>
		    </legend>
		    </strong></div>
		  <div>
		    <p><strong>
	        <label for="Race">
            <span>Allergies:(If yes, please specify)</span></label>
	        </strong><strong>
            <input type="text" id="allergy" name = "allergy" />
            </strong></p>
		    <p><strong>
	        <label for="sport"><span>Student interested in sport:</span>
                  <br>
	          <label for="yes">
		      <br>
		      <input type="radio" name="sport" id="yes" value="yes">
	        yes</label>
		    <br>
  <input type="radio" id="no" name="sport" value="no">
  <label for="sport_no">no</label>
            </label>
		    </strong></p>
		  
			<p><strong>Requires further assistance in applications process</strong><strong><span>:</span>
                 <br>
               <label for="yes">
		      <br>
		      <input type="radio" name="assistance" id="yes" value="yes">
	        yes</label>
		    <br>
  <input type="radio" id="no" name="assistance" value="no">
  <label for="app_no">no</label>
			</strong></p>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
		  </div>	
			<p><strong><br>
		    GENDER<br>
		    <label for="male">
		      <input type="radio" name="gender" id="male" value="m">
		      Male</label>
		    <br>
  <input type="radio" id="female" name="gender" value="f">
  <label for="female">Female</label>
  <br>
  <input type="radio" id="other" name="gender" value="o">
  <label for="other">Other</label>
		    

		    <p>
              <tr><td><input type='submit' value='SUBMIT' name ='submit'></td><td></td></tr>
		      <br>
		      
		      
    </fieldset>		
			
</form>

      </div>
    </section><!-- End Recommendations Section -->


<!-- ======= Sports Section ======= -->
    <section id="sports" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Find certain sports activities to consider available at certain institutions below</h2>
        </div>
         
        <div class="row content">
          <div class="col-lg-6">
           <ul>
              <li><i class="ri-check-double-line"></i> Rugby is a common sport found in a number of institutions like UFS, WSU, UFH,etc.</li>
              <li><i class="ri-check-double-line"></i> Soccer is a very active sport that can be found in a variety of institutions including UFS, WSU, UJ, WITS,etc.</li>
              <li><i class="ri-check-double-line"></i> Netball is a female dominated sport activity available in most higher institutions following DUT, UWC, NMU, etc.</li>
              <li><i class="ri-check-double-line"></i> Softball is a fun sport activity enlisted in a number of higher institutions like UFS, WITS, UP, UJ, etc</li>
              <li><i class="ri-check-double-line"></i> Volley Ball is a active sport not so common but available in some institutions like UFS, UCT, UCP, etc.</li>
              <li><i class="ri-check-double-line"></i> Tennis is a sport that accomodates all genders, but mostly female dominated and can be found in a variety of institutions including UCT, UFS, UFH, etc</li> 
              <li><i class="ri-check-double-line"></i> Boxing is a self-defense based sport activity common in a number of institutions like WSU, UFH, UFS, etc.</li>
              <li><i class="ri-check-double-line"></i> Chess is a very mind-training sport more than physic activities and is common in most institutions following UJ, UFS, WSU, NMU, etc.</li>
            </ul>
           
          </div>
          <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="100">
          <img src="OIP.jpg" class="img-fluid animated" alt="">
          </div>
        </div>

      </div>
    </section><!-- End Sports Section -->

     <!-- ======= University Applications Section ======= -->
    <section id="university" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>University Applications</h2>
        </div>
         
        <div class="row content">
          <div class="col-lg-6">
           <ul>
              <li><i class="ri-check-double-line"></i> The university of Fort hare - <a href = https://www.ufh.ac.za>Vist here</a></li>
              <li><i class="ri-check-double-line"></i> Tshwane university of technology - <a href = https://www.tut.ac.za>Visit here</a></li>
              <li><i class="ri-check-double-line"></i> Walter Sisulu university - <a href = https://www.wsu.ac.za/index.php/how-to-apply-the-process-wsu>Visit here</a></li>
              <li><i class="ri-check-double-line"></i> University of Witwatersrand - <a href = https://www.wits.ac.za/applications/>Visit here</a></li>
              <li><i class="ri-check-double-line"></i>Rhodes university - <a href = https://ross.ru.ac.za>Visit here</a></li>
              <li><i class="ri-check-double-line"></i> Rhodes university - <a href = https://ross.ru.ac.za>Visit here</a></li>
              <li><i class="ri-check-double-line"></i> University of Johannesburg - <a href = https://www.uj.ac.za>Visit here</a></li>
              <li><i class="ri-check-double-line"></i> North west university - <a href = https://studies.nwu.ac.za>Visit here</a></li>
              <li><i class="ri-check-double-line"></i> University of free state - <a href = https://www.ufs.ac.za>Visit here</a></li>
              <li><i class="ri-check-double-line"></i>Nelson mandela university - <a href = https://www.mandela.ac.za>Visit here</a> </li>
              <li><i class="ri-check-double-line"></i>Cape peninsula university of technology - <a href = https://www.cput.ac.za>Visit here</a></i> </li>
            </ul>
           
          </div>
          <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="Spic.jpg" class="img-fluid animated" alt="">
          </div>
        </div>

      </div>
    </section><!-- End University Applications Section -->


  <!-- ======= Bursaries Section ======= -->
    <section id="bursary" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Busrsaries/Funding to consider for tuition fees</h2>
        </div>
         
        <div class="row content">
          <div class="col-lg-6">
           <ul>
              <li><i class="ri-check-double-line"></i><b> NSFAS </b>- <a href = https://my.nsfas.org.za/>Vist here</a></li>
               <br>
               <br>
               <div class="col-lg-6 double-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
               <img src="NSFAS.png" class="img-fluid animated" alt="">
               </div>
               <br>
               <br>
              <li><i class="ri-check-double-line"></i><b> FUNDI </b>- <a href = https://www.fundi.co.za/Bursary>Visit here</a></li>
               <br>
               <br>
              <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
              <img src="FUNDI.jpg" class="img-fluid animated" alt="">
              </div>
               <br>
               <br>
              <li><i class="ri-check-double-line"></i><b> THUTHUKA </b>- <a href = https://www.thuthukabursaryfund.co.za/>Visit here</a></li>
               <br>
               <br>
               <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
               <img src="THUTHUKA.jpg" class="img-fluid animated" alt="">
               </div>
               <br>
               <br>
              <li><i class="ri-check-double-line"></i><b> FUNZA LUSHAKA </b>- <a href = http://www.funzalushaka.doe.gov.za/>Visit here</a></li>
               <br>
               <br>
              <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
              <img src="FUNZA.png" class="img-fluid animated" alt="">
              </div>
           
            </ul>
           
          </div>
          <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="bursaries.png" class="img-fluid animated" alt="">
          </div>
        </div>

      </div>
    </section><!-- End Bursaries Section -->


<!-- ======= Faculties Section ======= -->
    <section id="Faculties" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Faculties</h2>
         <h3>Here are Faculties to look into as recommended by the school as according to the subjects available in the school</h3>

   <!-- ======= Law Section ======= -->
  <section id="law" class="team section-bg">
  <li>Law</li>
   <p>Law is recommended by the school as some of the subjects available in<br>
      the school match with the field. For further assistance in the field, visit <br>
      the staff page by clicking on the link below to access details of Mr K Somagaca whom is<br>
      responsible for assisting learners whom seek assistance in the particular field of study </p>

  </section><!-- End Law Section -->

 <!-- ======= Humanities Section ======= -->
  <section id="humanities" class="team section-bg">

 <li>Humanities</li>
   <p>Humanities is recommended by the school as some of the subjects available in<br>
      the school match with the field. For further assistance in the field, visit <br>
      the staff page by clicking on the link below to access details of Mrs V Gebe whom is<br>
      responsible for assisting learners whom seek assistance in the particular field of study </p>

</section><!-- End Humanities Section -->

<!-- ======= Health Sciences Section ======= -->
  <section id="health" class="team section-bg">

 <li>Health Sciences</li>
   <p>Health Sciences is recommended by the school as some of the subjects available in<br>
      the school match with the field. For further assistance in the field, visit <br>
      the staff page by clicking on the link below to access details of Mr A Rasmeni whom is<br>
      responsible for assisting learners whom seek assistance in the particular field of study </p>

</section><!-- End Health Sciences Section -->

<!-- ======= Engineering and Information Technology Section ======= -->
  <section id="engineering" class="team section-bg">

 <li>Engineering and Information Technology</li>
   <p>Faculty of Engineering and Information Technology is recommended by the school as some of the subjects available in<br>
      the school match with the field. For further assistance in the field, visit <br>
      the staff page by clicking on the link below to access details of Mr SA Nogemane whom is<br>
      responsible for assisting learners whom seek assistance in the particular field of study </p>

</section><!-- End Engineering and Information Section -->

<!-- ======= Education Section ======= -->
  <section id="education" class="team section-bg">

 <li>Education</li>
   <p>Education is recommended by the school as some of the subjects available in<br>
      the school match with the field. For further assistance in the field, visit <br>
      the staff page by clicking on the link below to access details of Mr O Mahlakatha whom is<br>
      responsible for assisting learners whom seek assistance in the particular field of study </p>

</section><!-- End Education Section -->

        </div>
      </div>
     </section><!-- End Faculties Section -->


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    

    <div class="footer-top">
      <div class="container">
        <div class="row">

         

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#hero">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#about">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#staff">Staff</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#sports">Sports</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#university">Applications</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#Busary">Bursaries</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Faculties</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Law</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Health Science</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Engineering and Information Technology</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Education</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Humanities</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Social Networks</h4>
            <p>We are also available on the following social plartforms</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  
  <script src="assets/js/main.js"></script>

</body>

</html>

<?php

require_once'connection.php';

$grade = $date = $email = $number = $allergy = $sport = $assistance = $gender =" ";

if(isset($_POST['grade']))
{
  $grade= $_POST['grade'];
  $date = $_POST['date'];
  $email= $_POST['email'];
  $number = $_POST['number'];
  $allergy = $_POST['allergy'];
  $sport = $_POST['sport'];
  $assistance = $_POST['assistance'];
  $gender = $_POST['gender'];


}

if(isset($_POST['submit']))
{

$query = "INSERT INTO users(grade,date,email,number,allergy,sport,assistance,gender)VALUES('$grade','$date','$email','$number','$allergy','$sport','$assistance','$gender')";

$result = $con->query($query);

if(!$result)
{die($con->error);
echo"alert('There was an issue uploading your details,please try again or contact an administrator')";
}
else
{

echo"alert('Details submitted!')";
}
}