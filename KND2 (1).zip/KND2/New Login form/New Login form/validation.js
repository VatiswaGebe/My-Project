var isPassword = false;
var isEmail = false;

function email_validation(){
    var emailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var email = document.getElementById('email').value;
    email = email.trim();

    //document.getElementById('email').style.color = "Red";
    document.getElementById('email').style.border = "2px red double";
    if (email.length < 10){
        //document.getElementById('email').focus();
        alert('Email address can\'t be less than 10 characters');
        return;
    }
    if (!email.match(emailformat)){ 
        //document.getElementById('email').focus();
        alert('Invalid email address, email addres should contain @ sign and the top level domain');
        return;
    }

    document.getElementById('email-error').innerHTML = "";
    document.getElementById('email').style.border = "2px green double";
    isEmail = true;
}

function password_validation(){

    var password = document.getElementById('password').value;
    var passwordFormat=  /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,150}$/;
    password = password.trim();

    document.getElementById('password').style.border = "2px red double";

    if (password.length < 8){
        //document.getElementById('password').focus();
        alert('Password should be at leats 8 characters long');
        return;
    }
    if (!password.match(passwordFormat)){
        //document.getElementById('password').focus();
        alert('Password should lower case letters, upper case letters, numbers and special characters');
        return;
    }
    document.getElementById('password').style.border = "2px green double";
    isPassword = true;
}

function isValidationPassed(){
    if (isEmail == false){
        document.getElementById('email').focus();
        email_validation();
        return;
    }
    if (isPassword == false){
        document.getElementById('password').focus();
        password_validation();
        return;
    }
}