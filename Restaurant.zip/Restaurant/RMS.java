/**
 * Kazunori Hayashi
* Version 1.0 13/7/
* 2013
 */
public class RMS
{
	public static void main(String[] args) {
		Controller cController = new Controller();
		cController.mainLoop();
	}
}
